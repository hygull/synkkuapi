      Table "public.states"
   Column   |            Type             |                      Modifiers                      
------------+-----------------------------+-----------------------------------------------------
 id         | bigint                      | not null default nextval('states_id_seq'::regclass)
 statename  | character varying(50)       | not null
 country_id | integer                     | not null
 status     | smallint                    | not null
 created_on | timestamp without time zone | default now()
 updated_on | timestamp without time zone | 
Indexes:
    "states_pkey" PRIMARY KEY, btree (id)



                                     Table "public.users_details"
      
         Column          |            Type             |                         Modifiers                          
-------------------------+-----------------------------+------------------------------------------------------------
 id                      | bigint                      | not null default nextval('users_details_id_seq'::regclass)
 user_id                 | integer                     | not null
 current_address         | text                        | not null
 current_address_pincode | integer                     | not null
 current_address_state   | integer                     | not null
 present_address         | text                        | not null
 present_address_pincode | integer                     | not null
 present_address_state   | integer                     | not null
 created_on              | timestamp without time zone | default now()
 updated_on              | timestamp without time zone | 
Indexes:
    "users_details_pkey" PRIMARY KEY, btree (id)



    Table "public.users_workexperience"
   Column   |            Type             |                             Modifiers                             
------------+-----------------------------+-------------------------------------------------------------------
 id         | bigint                      | not null default nextval('users_workexperience_id_seq'::regclass)
 user_id    | integer                     | not null
 company_id | integer                     | not null
 start_date | date                        | default '1900-01-01'::date
 end_date   | date                        | 
 created_on | timestamp without time zone | default now()
 updated_on | timestamp without time zone | 
Indexes:
    "users_workexperience_pkey" PRIMARY KEY, btree (id)